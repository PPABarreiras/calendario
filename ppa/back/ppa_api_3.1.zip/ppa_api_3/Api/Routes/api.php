<?php

// REQUISITA OS ARQUIVOS DAS ROTAS
require_once dirname(__DIR__) . '/Routes/auth.php';
require_once dirname(__DIR__) . '/Routes/register.php';
require_once dirname(__DIR__) . '/Routes/class.php';
require_once dirname(__DIR__) . '/Routes/student.php';
require_once dirname(__DIR__) . '/Routes/teacher.php';
